function ctof() {
    let c = document.getElementById("c").value;
    let f = c * (9 / 5) + 32;
    document.getElementById("resultC").innerHTML = f.toFixed(2) + " °F";
  }

  function ftoc() {
    let f = document.getElementById("f").value;
    let c = (f - 32) * (5 / 9);
    document.getElementById("resultF").innerHTML = c.toFixed(2) + " °C";
  }